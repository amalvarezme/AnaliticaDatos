# -*- coding: utf-8 -*-
"""
Created on Thu Sep 26 09:37:20 2019

@author: andre
"""
#%% librerias a importar
import os
from sklearn.impute import SimpleImputer 
from sklearn.preprocessing import OrdinalEncoder,OneHotEncoder
from sklearn.base import  BaseEstimator, TransformerMixin
import pandas as pd
import numpy as np
from sklearn.decomposition import PCA 
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")
#%% Analisis exploratorio basico - base de datos housing
def pre_exploratorio(Xtrain_pre,ytrain_pre,path_img,col_sal,Np=None):
    #exploratorio basico -> Normalizar + reduccion de dimensionalidad
    normalizar = StandardScaler()
    #escoger aleatoriamente puntos para evitar costo computacional - analisis inicial
    if Np == None: Np = len(Xtrain_pre.index)
    
    ind = np.random.randint(0,len(Xtrain_pre.index),Np) #escoger subconjunto de datos
    
    Xz = normalizar.fit_transform(Xtrain_pre.iloc[ind,:])
    yc = ytrain_pre[ind].reshape(-1)
    
    #reduccion de dimension con pca y tsne
    red_pca = PCA()
    perplexity = np.round(0.5*np.sqrt(Np))
    red_tsne = TSNE(n_components=2,perplexity = perplexity, n_iter = 250,verbose = 10)
        
    Xred_pca = pd.DataFrame(red_pca.fit_transform(Xz))
    Xred_tsne = pd.DataFrame(red_tsne.fit_transform(Xz))
  
    #Relevancia por variabilidad
    var_ret = 0.95
    rel_vec,Mv,ind_rel = rel_pca(red_pca,var_ret)
    
    #graficar
    sval = 30
    #pca 2D
    Xred_pca.plot(kind="scatter",x=0,y=1,
               c = yc, s=sval, label = col_sal,
              colormap = "jet",colorbar=True, sharex=False)    
    plt.title('PCA 2D')
    plt.xlabel('Componente principal 1')
    plt.ylabel('Componente principal 2')
    save_fig(path_img,"red_PCA2D")
    plt.show()
    
    #relevancia pca 2D     
    plt.stem(np.arange(len(Xtrain_pre.columns)),rel_vec[ind_rel])
    plt.xticks(np.arange(len(Xtrain_pre.columns)), 
           Xtrain_pre.columns[ind_rel],rotation =90,fontsize=12)
    plt.ylabel('Relevancia PCA')
    plt.title('RELEVANCIA PCA, var_ret=%.2f' % (var_ret))
    save_fig(path_img,"relevancia_PCA")
    plt.show()
    #tsne 2D
    Xred_tsne.plot(kind="scatter",x=0,y=1,
               c = yc, s = sval, label = col_sal,
              colormap = "jet",colorbar=True, sharex=False)    
    plt.title('t-sne 2D - Perp.=%.2f' % perplexity)
    plt.xlabel('Embebimiento - Dim. 1')
    plt.ylabel('Embebimiento - Dim. 2')
    save_fig(path_img,"tsne_2D")
    plt.show()
    
    return True
#%% relevancia por variabilidad con pca
def rel_pca(red,var_exp):
    Mv = np.min(np.where(np.cumsum(red.explained_variance_ratio_)
                         >var_exp))
    P,M = red.components_.shape
    rel_vec = np.zeros((P))
    for i in range(Mv):
        rel_vec += abs(red.explained_variance_ratio_[i]*red.components_[i,:])
    
    rel_vec = rel_vec/sum(rel_vec)
    rel_vec = rel_vec - min(rel_vec)
    rel_vec = rel_vec/max(rel_vec)
    
    ind_rel = rel_vec.argsort()[::-1]
    return rel_vec, Mv,ind_rel

#%%  guardar figuras
def save_fig(path_img,fig_id, tight_layout=True, fig_extension="png", resolution=300):
    path = os.path.join(path_img, fig_id + "." + fig_extension)
    print("Guardando...", fig_id)
    if tight_layout:
        plt.tight_layout()
    plt.savefig(path, format=fig_extension, dpi=resolution)

#%% dummy transformer

class dummy_transformer(BaseEstimator,TransformerMixin):
    #inicializacion de clase y varaibles
    def __init__(self, num_strategy="most_frequent",code_cat ="ordinal",categories='auto'):
        self.code_cat = code_cat #tipo de codificacion binaria u ordinal
        self.num_strategy  = num_strategy
        self.cat_strategy  = "most_frequent"
        self.categories = categories

    def fit(self,X, *_):
        self.imputer_num = SimpleImputer(strategy=self.num_strategy).fit(X[X.columns[X.dtypes!='O']])
        self.imputer_cat = SimpleImputer(strategy=self.cat_strategy).fit(X[X.columns[X.dtypes=='O']])
        if self.code_cat == "binary": self.cod = OneHotEncoder(categories=self.categories)
        else: self.cod = OrdinalEncoder(categories=self.categories)
        self.cod.fit(X[X.columns[X.dtypes=='O']])
        
        return self    

    def transform(self, X, *_):
        Xi = X.copy()
        Xi[X.columns[X.dtypes!='O']] = self.imputer_num.transform(X[X.columns[X.dtypes!='O']])
        Xi[X.columns[X.dtypes=='O']] = self.imputer_cat.transform(X[X.columns[X.dtypes=='O']])
        if self.code_cat == "ordinal":
            Xi[X.columns[X.dtypes=='O']] = self.cod.transform(Xi[X.columns[X.dtypes=='O']])
        elif self.code_cat == "binary":
             Xdb = self.cod.transform(Xi[X.columns[X.dtypes=='O']])
             Xi.drop(columns=X.columns[X.dtypes=='O'],inplace=True)
             for i in range(Xdb.toarray().shape[1]):
                 Xi['b_'+str(i+1)] = Xdb[:,i].toarray()
        return Xi
    
    def fit_transform(self,X,*_):
        self.fit(X)
        return self.transform(X)
#%%    
'''
#ejemplo de uso
#% Paso 1: lectura datos
import pandas as pd
import numpy as np
import warnings
from sklearn.model_selection import train_test_split, GridSearchCV,cross_val_score, cross_val_predict
from sklearn.metrics import mean_absolute_error
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
warnings.filterwarnings("ignore")

csv_path = 'datos/housing.csv'
img_path = 'resultados/'
Xdata = pd.read_csv(csv_path)
#% Paso 2: particion xtrain, xtest
Xtrain, Xtest = train_test_split(Xdata,test_size=0.3)
col_sal = "median_house_value"
ytrain = Xtrain[col_sal]
ytest = Xtest[col_sal]
Xtrain.drop(columns=col_sal,inplace=True)
Xtest.drop(columns=col_sal,inplace=True)
#% Paso 3 : Analisis exploratorio
#preproceso entrada  y salida para analisis exploratorio
ytrain = SimpleImputer(strategy="most_frequent").fit_transform(pd.DataFrame(ytrain))
Xtrain_pre = dummy_transformer().fit_transform(Xtrain)
pre_exploratorio(Xtrain_pre,ytrain,img_path,col_sal)
#% Paso 4 : Escoger modelo por gridsearchCV utilizando pipeline
steps=[('dummy_pre', dummy_transformer()),
                ('red', PCA()),('reg', LinearRegression())]
pipeline = Pipeline(steps = steps)

parameters = {'dummy_pre__code_cat':["ordinal","binary"], 
              'dummy_pre__num_strategy':["median","most_frequent"],
              'red__n_components':[0.7,0.8,0.9,0.95]}
grid_search = GridSearchCV(pipeline, parameters, n_jobs=4,cv=5,
                           scoring='neg_mean_absolute_error',verbose=10)
grid_search.fit(Xtrain, ytrain)
best_model = grid_search.best_estimator_

print("\nMejores parámetros:\n")
print(grid_search.best_params_)
#% Paso 5: evaluar sobre Xtest
ytest_e = best_model.predict(Xtest)
vmae = mean_absolute_error(ytest.to_numpy().reshape(1,-1),ytest_e.reshape(1,-1),multioutput='raw_values')
plt.boxplot(vmae)
print('mae(test)=%.2f' % mean_absolute_error(ytest,ytest_e))
plt.xticks([1],labels=['mae(testing_set)'])
plt.ylabel('mae -- $ USD')
plt.title('mae=%.2f'% mean_absolute_error(ytest,ytest_e))
save_fig(img_path,"mae_testing_set")
plt.show()
##########
#opcional: validar parametros del mejor estimador utilizando cv
scores = cross_val_score(best_model, Xtrain, ytrain, cv=10,n_jobs = -1,scoring='neg_mean_absolute_error',verbose=10)
plt.boxplot(-scores)
plt.xticks([1],labels=['mae(validation_set)'])
plt.ylabel('mae -- $ USD')
plt.title('mae=%.2f'% np.mean(-scores))
save_fig(img_path,"mae_validation_set")
plt.show()
#%%
#predicts = cross_val_predict(best_model, Xtrain, ytrain, cv=10,n_jobs = -1,verbose=10)
'''
